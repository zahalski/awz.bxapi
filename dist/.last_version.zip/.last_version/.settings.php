<?php
return array(
    'controllers' => array(
        'value' => array(
            'namespaces' => array(
                '\\Awz\\bxApi\\Api\\Controller' => 'api'
            )
        ),
        'readonly' => true
    )
);
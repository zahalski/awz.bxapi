<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>
<?global $APPLICATION;?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <?$APPLICATION->ShowHead()?>
    <script src="//api.bitrix24.com/api/v1/"></script>
</head>
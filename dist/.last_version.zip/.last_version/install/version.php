<?
$arModuleVersion = array(
	"VERSION" => "1.0.6",
	"VERSION_DATE" => "2023-06-08 17:54:00"
);
?>
<?
$arModuleVersion = array(
	"VERSION" => "1.1.3",
	"VERSION_DATE" => "2023-08-08 11:41:00"
);
?>
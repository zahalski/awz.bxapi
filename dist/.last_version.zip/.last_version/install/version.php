<?
$arModuleVersion = array(
	"VERSION" => "1.1.4",
	"VERSION_DATE" => "2023-09-12 22:26:00"
);
?>
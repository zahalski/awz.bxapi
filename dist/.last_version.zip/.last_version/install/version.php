<?
$arModuleVersion = array(
	"VERSION" => "1.0.3",
	"VERSION_DATE" => "2023-02-21 16:03:00"
);
?>